import React from 'react'

function Footer() {
  return (
    <div>
        <div className="footer">
          <p style={{color:'black'}}>Copyright © 2022 Edu Meeting Co., Ltd. All Rights Reserved.
            <br />Design : <a href="https://templatemo.com" target="_parent" title="free css templates">TemplateMo</a></p>
        </div>
    </div>
  )
}

export default Footer
