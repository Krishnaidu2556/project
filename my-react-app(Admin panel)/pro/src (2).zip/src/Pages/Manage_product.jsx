import React from 'react'

function Manage_product() {
  return (
    <footer className="main-footer">
    <div className="pull-center hidden-xs">
     <h1>Manage Product</h1>
    </div>
    
  </footer>
  )
}

export default Manage_product
