import React from 'react'

function Manage_product() {
  return (
    <div>
      <h1>wedfgebnhg</h1>
    </div>
  )
}

export default Manage_product
