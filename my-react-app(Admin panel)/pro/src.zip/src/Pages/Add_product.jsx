import React from 'react'

function Add_product() {
  return (
    <div>
      <h1>wsdfvgrbthtgrfdcx</h1>
    </div>
  )
}

export default Add_product
