import React from 'react'

function Manage_Contact() {
  return (
    <div>
      <h1>wedfgrew2sd</h1>
    </div>
  )
}

export default Manage_Contact
